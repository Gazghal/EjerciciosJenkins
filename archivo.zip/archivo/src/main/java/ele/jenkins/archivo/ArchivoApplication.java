package ele.jenkins.archivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchivoApplication.class, args);
	}

}
