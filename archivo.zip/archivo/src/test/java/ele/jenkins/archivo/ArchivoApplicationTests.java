package ele.jenkins.archivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
